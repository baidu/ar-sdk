# DuMix AR iOS SDK 基础版开发者文档

# 简介

本文档主要介绍DuMix AR iOS SDK 基础版的安装和使用。在使用本文档前，您需要先了解AR（Augmented Reality）的基础知识，并已经开通了AR服务（您可以在 [DuMix AR官网](https://dumix.baidu.com) 的“开放平台”页面申请AR服务）。

# 快速入门

## 开发包说明

```
-DuMix AR iOS SDK基础版.zip
    |-ARSDK                                    // SDK模块
    |-BDARClientSample                         // Demo
    |-BDARClientSample.xcodeproj               // Demo的工程文件
    |-Vendors                                  // 所应用的三方库
    |-sample                                   // sample case(示例AR内容)
    |-DuMix AR iOS SDK开发文档.md               // 说明文档
```

DuMix AR iOS SDK运行环境如下：

- iOS: 8.0 以上
- 架构：arm64（代码可通过 `[BaiduARSDK isSupportAR]` 来判断当前设备是否支持AR功能）。

## SDK集成步骤

### 第1步：创建AR应用

***创建正式版AR应用：**
请先前往[百度云控制台](https://console.bce.baidu.com/ai/#/ai/ar/app/list)创建您的正式版AR应用:

![](https://ai.bdstatic.com/file/BB44EDFEEA4C47FFA05BFA6B8337B62C)

<br>
***创建试用版AR应用：**
请先前往[DuMix AR官网](https://dumix.baidu.com)的“开放平台”页面选择【免费试用】创建您的试用版AR应用:

![](https://ai.bdstatic.com/file/8ABE8765B10547AC90FC93B6FF148EA0)


### 第2步：引入编译需要的Framewrok

DuMixAR需要引入的系统库有 libz.tbd、libstdc++.tbd等

DuMixAR需要引入第三方库有 AFNetworking 、ZipArchive等

注：详细请参照Demo。

```
AFNetworking |版本为3.1.0 (https://github.com/AFNetworking/AFNetworking)
ZipArchive   |版本为1.2 (https://code.google.com/archive/p/ziparchive/downloads)
BDTTS  |可选项，百度语音融合SDK，请参考 https://ai.baidu.com 中【百度语音】
BDVoice|可选项，百度语音识别SDK，请参考 https://ai.baidu.com 中【百度语音】
```   

DuMixAR需要引入DuMixAR的静态库 DumixAR.a、DumixARCore.a

注：DuMixAR功能`只能`在真机环境下运行。

### 第3步：引入DuMixAR的头文件、自定义UI文件、资源文件和证书

DuMixAR 头文件在文件夹include下 
   
自定义UI 文件在文件夹OpenUI下

资源文件两部分：

* BaiduAR.bundle 存放配置文件、文字文件
* BaiduAR.xcassets 存放图片资源

SDK目录如下:

```
-ARSDK
|-AR-TTS                 // 百度TTS相关的部分，若您不使用该功能，该模块不需要添加
|-AR-Voice               // 百度语音相关的部分，若您不使用该功能，该模块不需要添加
|-AR-ImageSearch         // 百度识图功能
|-paddle                 // 百度手势识别功能，若您不使用该功能，该模块不需要添加
|-BaiduAR.bundle         // 配置文件
|-BaiduAR.xcassets       // 图片资源
|-DumixAR.a              // DuMixARSDK
|-DumixARCore.a          // DuMixARSDK
|-include                // 头文件
|-OpenUI                 // 自定义UI文件
```


### 第4步：工程设置

1、请设置工程的 Bundle Identifer ，内容为您创建应用时的iOS包名。

2、在工程设置中选择Build Settings，搜索 Other Linker Flags  并设置 -ObjC、-force_load、`your arsdk path`/libpaddle_capi_layers.a ，其中`your arsdk path`/libpaddle_capi_layers.a的路径配置是可选项，若您不想集成手势识别功能，您`不`需要在工程中添加paddle的文件，也`不`要设置该路径，详细请参照Demo工程。

3、证书设置：
 
> <mark>**如果您用的是正式版:**</mark>
> 
>&ensp;&ensp;&ensp;&ensp;创建完AR应用后，在“应用详情”页面下载license文件，并将license文件放到您应用的工程目录中（license文件名称必须为：aip.license ）

> <mark>**如果您用的是试用版：**</mark>
> 
> &ensp;&ensp;&ensp;&ensp;不要添加 aip.license 文件，并确保工程中无此文件


### 第5步： 设置资源路径和初始化SDK

请参照Demo工程中的AppDelegate.m文件。

```
#define APP_ID       @""    // 您创建应用的 AppID 
#define API_KEY      @""    // 您创建应用的 API_KEY
#define SECRET_KEY   @""    // 您创建应用的 SECRET_KEY

[BaiduARSDK setBundlePath:@"BaiduAR.bundle"];   // BaiduAR.bundle 为资源文件名
[BaiduARSDK setAppID: APP_ID APIKey: API_KEY andSecretKey: SECRET_KEY];

注：【正式用户】和【试用账户】的 APP_ID，API_KEY 可能不一样 ，
    试用账号可以不用填写 SECRET_KEY

```

### 第6步：设置DuMixAR回调

- BARViewClickEventBlock:
在使用者调起DuMixAR之前需要实现该回调，当DuMixAR内部需要打开一个scheme的时候会调用该block。

```
//代码示例：
[arVC setClickEventBlock:^(NSString* url) {
// your code 
}];
```

- BARViewCloseEventBlock:
在使用者调起DuMixAR之前需要实现该回调，当ar内部需要关闭自身的时候会调用该block。

```
//代码示例：
[arVC setCloseEventBlock:^(void){
// your code
}];
```

- BAROpenSDKShareBlock:
在使用者调起DuMixAR之前需要实现该回调，当ar内部需要分享一个H5页面的时候会调用该block。

```
//代码示例：
[tVC setOpenSDKShareBlock:^(NSString* title, NSString*description, UIImage* thumbImg, NSString* h5Url, NSInteger  shareType, NSString *videoOrImageUrl){
NSLog(@"%@", title);// H5页面的title
NSLog(@"%@", description);// H5页面的描述
NSLog(@"%@",thumbImg);// 分享的缩略图信息
NSLog(@"%@", h5Url);// H5页面的url
NSLog(@"%ld", shareType);// 分享的类型。0:代表分享的是图片  1:代表分享的是视频
NSLog(@"%@", videoOrImageUrl);// 分享的图片或者视频在远端的url
}];
```

- DumixARScreenImageOrVideoEventBlock:
在使用者调起DuMixAR之前<mark>可以</mark>实现该回调，当您想自定义分享时，可由该回调获取到DumixAR的截图或者视频路径，若您实现该回调，则BAROpenSDKShareBlock回调<mark>不会</mark>触发。

```
//代码示例：
[tVC setDumixARScreenImageOrVideoEventBlock:^(NSDictionary *data) {
    if(data){
        NSString *type = data[@"type"];
        if([type isEqualToString:@"image"]){
        	//图片
            UIImage *image = data[@"data"];
            if(image){
                // your code
            }
        }else{
            NSString *videoPath = data[@"data"];
            //本地视频路径
            if(videoPath.length>0){
                // your code
            }
        }
    }
}];
```

- DumixARRefuseEventBlock:
在使用者调起DuMixAR之前需要实现该回调，当您的设备不支持当前case的时会调用该block。

```
 [tVC setDumixARRefuseEventBlock:^(NSString *url) {
     NSLog(@"%@", url);// url为对应的帮助页面
 }];
```

注：调起DuMixAR请参照Demo工程中的ARDemoDetailViewController.m文件。

### 第7步：获取 AR Key 和 AR Type
完成以上6步，您已经完成DuMix AR SDK的集成。但想要预览AR内容，您还需要在AR内容平台（https://dumix.baidu.com/content）上传您自己的AR内容（DuMix AR提供了5个sample case）。AR内容上传完成后，平台会分配相应的 AR Key，您可以在“详情页面”查看 AR Key 和 AR Type。

注：只有审核通过并上线的case才能在客户端预览。

### 第8步：运行您的App
请将第7步获取的AR Key和AR Type 填入到您的代码中，如下所示：

```
NSString *arValue = @"{\"ar_type\":\"your_type\",\"ar_key\":\"your_key\"}"; 
BARViewController *arVC = [BaiduARSDK viewController: arValue arInfo:nil]; 
说明:
arValue为JSON字符串,内容为：{"ar_type":ar种类,"ar_key":"case的arkey"}
ar_type :AR类型，目前0代表2D跟踪类型，5代表SLAM类型，6为本地识图，7为云端识图 8为IMU。
ar_key:AR内容平台里申请的每个case的key
当ar_type为6或者7时，ar_key请传空字符串，即：
本地识图：{"ar_type":"6","ar_key":""}
云端识图：{"ar_type":"7","ar_key":""}
注：调起DumixAR请参照Demo工程中的ARDemoDetailViewController.m文件
```
运行您的App

##  其它设置
DuMixAR使用中需要用到相机权限、麦克风权限、相册权限：
（Privacy - Camera Usage Description、Privacy - Photo Library Usage Description、Privacy - Microphone Usage Description）
权限设置请参照 DuMixARDemo 中的info.plist。
完整示例请参照 DuMixARDemo。

## 语音功能的集成步骤
DuMix AR打通了和百度语音技术相关的接口，如果您想在AR内容中使用语音识别、语音合成等能力，在申请AR服务时勾选语音相关功能即可。

## 注意事项
注1：语音相关功能是可选功能，您可以根据需要选择性集成。

注2：如果勾选语音识别功能，App即可获得语音SDK权限。

注3：关于百度语音SDK更详细的介绍，请参考百度AI开放平台。（https://ai.baidu.com）中【语音技术】的相关章节。

若您选择使用语音识别功能，请在工程中加入SDK文件夹中的libAR-SClientSDK.a文件，同时需要添加您下载的百度语音识别功能库。

若您选择使用语音融合功能，请在工程中加入SDK文件夹中的libAR-TTS.a文件，同时需要添加您下载的百度语音合成功能库。

注4： LOGO识别与其他功能组合使用时，请注意性能问题。

## 如何使用DuMixARDemo
iOS SDK提供了一个可快速运行的demo工程，该工程已经集成了SDK，您只需直接打开DuMixARDemo的工程文件并修改相应的参数即可运行。

步骤如下：

1、工程设置，参考"SDK集成步骤"中的【第4步】;

2、获取 AR Key 和 AR Type ，参考"SDK集成步骤"中的【第7步】

3、将您获取的 AR Key 和 AR Type 填入到 ViewController.m 中，如下所示：

```
 @{ @"demotype":@"ar",
    @"ar_key":请输入你上传的slam的包对应的arkey,
    @"ar_type":@"5",
    @"title":@"单目SLAM （Monocular SLAM）",
    @"describe":@"即时定位与跟踪的AR效果，将AR内容自然地呈现在现实空间中，
    可广泛应用于3D人物角色、3D商品模型展示等场景，例如AR车展、AR宠物小精灵等。"
 }, 
 
 注 ： 只需根据您的功能替换 AR Key 和 AR Type ，未用到的功能，注释即可
```

4、运行DuMixARDemo，即可预览AR内容。


# 版本更新说明

**DuMix AR iOS SDK 2.0基础版-2017年11月**
提供单目SLAM、2D图像跟踪、本地识图、云端识图、语音识别和语音合成等功能。
<br>
**DuMix AR iOS SDK 2.1基础版-2018年03月**
提供滤镜等功能。
<br>
**DuMix AR iOS SDK 2.2基础版-2018年04月**
提供手势识别和LOGO识别等功能。
<br>
**DuMix AR iOS SDK 2.3基础版-2018年05月**
提供在线视频等功能。
