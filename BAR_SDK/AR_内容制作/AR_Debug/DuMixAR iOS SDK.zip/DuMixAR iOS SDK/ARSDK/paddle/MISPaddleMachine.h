//
//  MISPaddleMachine.h
//  MISImageSearchLib
//
//  Created by Li,Yan(MMS) on 2017/12/14.
//  Copyright © 2017年 百度在线. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MISPaddleMachine : NSObject

@end

//#ifdef BDMISSHOUBAIVERSION

@interface MISMMLInputMatrix: NSObject
@property (nonatomic,assign,readonly) int width; //宽
@property (nonatomic,assign,readonly) int height;//高
@property (nonatomic,assign,readonly) int channel;
@property (nonatomic,assign,readonly) float* pixels;//input
- (instancetype)initWithWith:(int)width andHeight:(int)height andChannel:(int)channel andInputPixels:(float *)pixels;
- (BOOL)inputValid;
@end

// error domain
static NSString *const MISMMLMachinInitErrorDomain =@"PaddleMachineInitError";

//error code
typedef NS_ENUM(NSInteger, MISPMachineErrorCode)
{
    MISMachineInitFailed =0,// machine初始化失败
};

//machine type
typedef NS_ENUM(NSInteger, MISPMachineType)
{
    MISPaddle =0,// paddle
};
@class MISMMLPredicateMatrix;
@interface MISMMLPaddleMachine: NSObject



typedef void (^MISMMLPaddleMachineLoadCallbackBlock) (MISMMLPaddleMachine *machine,NSError *error);
- (instancetype)initMachineWithModelURL:(NSString *)modelURL andType:(MISPMachineType)machineType withDecryptKey:(const unsigned char *)key withKeySize:(unsigned int) keysize withError:(NSError **)error;
- (void)createWithModelURL:(NSString *)modelURL andType:(MISPMachineType )machineType withDecryptKey:(const unsigned char *)key withKeySize:(unsigned int) keysize withComplete:(MISMMLPaddleMachineLoadCallbackBlock)callback;
- (MISMMLPredicateMatrix *)predicateWithInputMatrix:(MISMMLInputMatrix *)input;
- (BOOL)releaseMachine;

@end

@interface MISMMLPredicateMatrix: NSObject
@property(nonatomic, strong) NSNumber *height;
@property(nonatomic, strong) NSNumber *width;
@property(nonatomic, strong) id mmlPredicateMatrix;
- (float *)getOputForRowNum:(NSInteger)num;
@end
//#endif

