//
//  BARBoxViewController.h
//  ARSDK-Pro
//
//  Created by Asa on 2017/11/21.
//  Copyright © 2017年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BARViewController.h"
#import "BaiduARSDK.h"
#import "BARBaseUIView.h"

typedef void (^BARViewCloseEventBlock)(void);

@interface BARBoxViewController : BARViewController
@property (assign, nonatomic) kBARType arType;
//@property (nonatomic, copy) BARViewClickEventBlock clickEventBlock;
//@property (nonatomic, copy) BARViewCloseEventBlock closeEventBlock;

- (id)initWithCaseId:(NSString *)caseId ARType:(kBARType)arType;

@end
