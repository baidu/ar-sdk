//
//  BaiduARSDK.h
//  BaiduARSDK
//
//  Created by LiuQi on 15/6/15.
//  Copyright (c) 2015年 Baidu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BARViewController.h"
#import "BARSDKDelegate.h"
//#import "BARSDKDef.h"

// @class - BaiduARSDK
// @brief - 百度AR SDK

#define BARNSLocalizedString(key) [BaiduARSDK getBARLocalString:key]

@interface BaiduARSDK : NSObject

/**
 * 设置用户的 appid, apikey, secretKey;
 */
+ (void)setAppID:(NSString *)appId
          APIKey:(NSString *)apiKey
     andSecretKey:(NSString *)secretKey;

/**
 * 获取AR 视图
 */
+ (BARViewController*)viewController:(NSString*)arValue arInfo:(NSDictionary *)arInfo;

/**
 * 清空SDK 缓存
 */
+ (void)cleanCache;

/**
 * 获取SDK 缓存大小
 * @return byte
 */
+ (unsigned long)cacheSize;

/**
 * 设置资源路径,默认为BaiduAR.bundle
 */
+ (void)setBundlePath:(NSString*)path;

/**
 * 设置 SDK 代理
 */
+ (void)setSDKDelegate:(id<BARSDKDelegate>)delegate;

+ (void)setUseCustomView:(BOOL)param;

+ (NSString *)arDeviceInfo:(NSString *)arValue;
+ (NSString *)getResPath:(NSString *)fileName;
+ (NSString *)getBARLocalString:(NSString *)key;
+ (NSString *)getDeviceName;

+ (UIDeviceOrientation)currentOrientation;

+ (BOOL)isOpenSDK;
+ (BOOL)isSupportAR;
+ (void)openTimeStatistics:(BOOL)open;
+ (BOOL)isTimeStatisticsOpened;
+ (NSString *)arSdkVersion;

+ (BOOL)setLocalARResourceName:(NSString *)resName ;

@end
