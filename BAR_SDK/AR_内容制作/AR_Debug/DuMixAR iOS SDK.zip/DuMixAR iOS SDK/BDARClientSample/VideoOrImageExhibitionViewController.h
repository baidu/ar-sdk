//
//  VideoOrImageExhibitionViewController.h
//  ARAPP-Box
//
//  Created by yijieYan on 2018/3/14.
//  Copyright © 2018年 Asa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoOrImageExhibitionViewController : UIViewController

- (id)initControllerWithImage:(UIImage *)image;

- (id)initControllerWithVideoPath:(NSString *)videoPath;

@end
