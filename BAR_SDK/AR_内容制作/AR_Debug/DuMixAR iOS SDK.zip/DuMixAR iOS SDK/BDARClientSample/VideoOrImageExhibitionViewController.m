//
//  VideoOrImageExhibitionViewController.m
//  ARAPP-Box
//
//  Created by yijieYan on 2018/3/14.
//  Copyright © 2018年 Asa. All rights reserved.
//

#import "VideoOrImageExhibitionViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface VideoOrImageExhibitionViewController ()

@property (nonatomic,strong) UIView *contentView;
@property (nonatomic, strong) AVPlayerLayer *playerLayer;
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerItem *playerItem;
@property (nonatomic, copy) NSString *videoPath;
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, assign) NSInteger currentType;

@end

@implementation VideoOrImageExhibitionViewController

- (id)initControllerWithImage:(UIImage *)image{
    self = [super init];
    if(self){
        self.image = image;
        self.currentType = 0;
    }
    return self;
}

- (id)initControllerWithVideoPath:(NSString *)videoPath{
    self = [super init];
    if(self){
        self.videoPath = videoPath;
        self.currentType = 1;
    }
    return self;
}

- (void)dealloc {
    [self.playerItem removeObserver:self forKeyPath:@"status"];
    [self.playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackLikelyToKeepUp"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if(self){
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(20, 20, 100, 30)];
        [button addTarget:self action:@selector(onClicked) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"关闭" forState:UIControlStateNormal];
        [self.view addSubview:button];
        self.view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.8];
        CGRect frame = [UIScreen mainScreen].bounds;
        self.contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width/2, frame.size.height/2)];
        self.contentView.center = CGPointMake(frame.size.width/2, frame.size.height/2);
        [self.view addSubview:self.contentView];
        
        if(self.currentType ==0){
            [self showImageView:self.image];
        }else{
            [self showVideoView:self.videoPath];
        }
    }
    // Do any additional setup after loading the view.
}

- (void)onClicked{
    [self removeObserver];
    
    [self.navigationController   popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)showImageView:(UIImage *)image{
    UIImageView *mimageView = [[UIImageView alloc]initWithFrame:self.contentView.bounds];
    mimageView.image = image;
    [self.contentView addSubview:mimageView];
}

- (void)showVideoView:(NSString *)videoPath{
    self.videoPath = videoPath;
    [self prepareToPlay];
}


- (void) videoPlayerDidEnd:(NSNotification *) notification {
    if ([notification.object isKindOfClass:[AVPlayerItem class]] ) {
        if (notification.object == self.playerItem) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self.player seekToTime:kCMTimeZero];
                [self play];
            });
        }
    }
}

- (void) observeValueForKeyPath:(NSString *)keyPath
                       ofObject:(id)object
                         change:(NSDictionary<NSString *,id> *)change
                        context:(void *)context{
    if (object == self.playerItem) {
        if ([keyPath isEqualToString:@"status"]) {
            if (self.playerItem.status == AVPlayerStatusReadyToPlay) {
                //准备好了，准备播放
                
            }else if( self.playerItem.status == AVPlayerItemStatusFailed) {
                //出错了
                
            }
        }else if ([keyPath isEqualToString:@"loadedTimeRanges"]) {
            //计算缓冲时间
            //            NSTimeInterval timeInterval = [self availableDuration];// 计算缓冲进度
            //            CMTime duration = self.playerItem.duration;
            //            CGFloat totalDuration = CMTimeGetSeconds(duration);
        }else if ([keyPath isEqualToString:@"playbackBufferEmpty"]) {
            //缓存空了
            if (self.playerItem.playbackBufferEmpty) {
                
                [self play];
            }
        }else if([keyPath isEqualToString:@"playbackLikelyToKeepUp"]){
            //又有缓存了
            if (self.playerItem.playbackLikelyToKeepUp) {
                
            }
        }
    }
}


- (void)play{
    [self.player play];
}

- (void) prepareToPlay {
    
    [self removeObserver];
    
    
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isDir = NO;
    BOOL local = [fileManager fileExistsAtPath:self.videoPath isDirectory:&isDir];
    
    if (local) {
        self.playerItem = [AVPlayerItem playerItemWithAsset:[AVAsset assetWithURL:[NSURL fileURLWithPath:self.videoPath]]];
    }else{
        return;
    }
    
    self.player = [AVPlayer playerWithPlayerItem:self.playerItem];
    self.playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    self.playerLayer.frame = self.contentView.frame;
    //self.playerLayer.videoGravity = AVLayerVideoGravityResizeAspect;
    self.playerLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    
    [self.view.layer insertSublayer:self.playerLayer atIndex:0];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(videoPlayerDidEnd:)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:self.player.currentItem];
    
    [self.playerItem addObserver:self
                      forKeyPath:@"status"
                         options:NSKeyValueObservingOptionNew
                         context:nil];
    [self.playerItem addObserver:self
                      forKeyPath:@"loadedTimeRanges"
                         options:NSKeyValueObservingOptionNew
                         context:nil];
    [self.playerItem addObserver:self
                      forKeyPath:@"playbackBufferEmpty"
                         options:NSKeyValueObservingOptionNew
                         context:nil];
    [self.playerItem addObserver:self
                      forKeyPath:@"playbackLikelyToKeepUp"
                         options:NSKeyValueObservingOptionNew
                         context:nil];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self play];
    });
}



- (void) removeObserver {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (self.playerItem) {
        [self.playerItem removeObserver:self forKeyPath:@"status"];
        [self.playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
        [self.playerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
        [self.playerItem removeObserver:self forKeyPath:@"playbackLikelyToKeepUp"];
    }
    [self removePlayer];
}

- (void) removePlayer {
    if(self.playerLayer) {
        [self.playerLayer removeFromSuperlayer];
        self.playerLayer = nil;
    }
    if (self.player) {
        self.player = nil;
    }
    if (self.playerItem) {
        self.playerItem = nil;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
