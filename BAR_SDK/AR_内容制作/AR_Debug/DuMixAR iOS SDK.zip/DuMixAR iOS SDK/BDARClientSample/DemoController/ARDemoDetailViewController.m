//
//  ARDemoDetailViewController.m
//  BDARClientSample
//
//  Created by yijieYan on 2017/6/21.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import "ARDemoDetailViewController.h"
#if TARGET_IPHONE_SIMULATOR
#else
#import "BaiduARSDK.h"
#import "BARViewController.h"
#endif
#import "VideoOrImageExhibitionViewController.h"

@interface ARDemoDetailViewController ()

@end

@implementation ARDemoDetailViewController

- (void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    UIBarButtonItem * backButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    self.navigationItem.leftBarButtonItem = backButtonItem;
    [self buildView];
    
    // Do any additional setup after loading the view.
}

- (void)buildView {
    
    UITextView *textView = [[UITextView alloc]initWithFrame:CGRectZero];
    textView.frame = CGRectMake(5, 5, self.view.frame.size.width-10, self.view.frame.size.height-10);
    textView.editable = NO;

    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 4;
    
    NSDictionary *attributes = @{
                                 NSFontAttributeName:[UIFont systemFontOfSize:18],
                                 NSParagraphStyleAttributeName:paragraphStyle
                                 };
    textView.attributedText = [[NSAttributedString alloc] initWithString:_arDic[@"describe"] attributes:attributes];
    
     [self.view addSubview:textView];
    
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.frame)-60, CGRectGetWidth(self.view.frame), 60)];
    [button setTitle:@"调起AR" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.backgroundColor = [UIColor colorWithRed:81.0/255 green:178.0/255 blue:205.0/255 alpha:1];
    [button addTarget:self action:@selector(onButtonClicked)
     forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];

    button.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSLayoutConstraint *trailing =[NSLayoutConstraint
                                   constraintWithItem:button
                                   attribute:NSLayoutAttributeTrailing
                                   relatedBy:NSLayoutRelationEqual
                                   toItem:self.view
                                   attribute:NSLayoutAttributeTrailing
                                   multiplier:1.0f
                                   constant:0.f];
    
    NSLayoutConstraint *leading = [NSLayoutConstraint
                                   constraintWithItem:button
                                   attribute:NSLayoutAttributeLeading
                                   relatedBy:NSLayoutRelationEqual
                                   toItem:self.view
                                   attribute:NSLayoutAttributeLeading
                                   multiplier:1.0f
                                   constant:0.f];
    
    NSLayoutConstraint *bottom =[NSLayoutConstraint
                                 constraintWithItem:button
                                 attribute:NSLayoutAttributeBottom
                                 relatedBy:NSLayoutRelationEqual
                                 toItem:self.view
                                 attribute:NSLayoutAttributeBottom
                                 multiplier:1.0f
                                 constant:0.f];
    
    NSLayoutConstraint *height = [NSLayoutConstraint
                                  constraintWithItem:button
                                  attribute:NSLayoutAttributeHeight
                                  relatedBy:NSLayoutRelationEqual
                                  toItem:nil
                                  attribute:NSLayoutAttributeNotAnAttribute
                                  multiplier:0
                                  constant:60];
    
    [self.view addConstraint:trailing];
    [self.view addConstraint:bottom];
    [self.view addConstraint:leading];
    [button addConstraint:height];

}

- (void)onButtonClicked {
#if TARGET_IPHONE_SIMULATOR
#else
    NSDictionary *dic = @{@"ar_key":_arDic[@"ar_key"],@"ar_type":_arDic[@"ar_type"]};
    NSString *value = [self dicToString:dic];
    
    BARViewController *arVC = [BaiduARSDK viewController:value  arInfo:nil];
    __weak BARViewController *weakARVC = arVC;

    __weak typeof (self) weakSelf = self;
    [arVC setClickEventBlock:^(NSString* url) {
        
        if (weakSelf) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.navigationController popToRootViewControllerAnimated:NO];
                [weakSelf.navigationController.navigationBar setHidden:NO];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
            });
        }
    }];
    
    
    //退化方案，当您的设备不支持当前case的时候会跳转到帮助页面
    [arVC setDumixARRefuseEventBlock:^(NSString *url) {
        if (weakSelf) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.navigationController popToRootViewControllerAnimated:NO];
                [weakSelf.navigationController.navigationBar setHidden:NO];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
            });
        }
    }];
    
    [arVC setCloseEventBlock:^(void){
        if (weakSelf) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakARVC.navigationController popViewControllerAnimated:YES];
                [weakSelf.navigationController.navigationBar setHidden:NO];
            });
        }
    }];
    
//    [arVC setDumixARScreenImageOrVideoEventBlock:^(NSDictionary *data) {
//        if(data){
//            NSString *type = data[@"type"];
//            if([type isEqualToString:@"image"]){
//                UIImage *image = data[@"data"];
//                if(image){
//                    [weakSelf handleImage:image];
//                }
//            }else{
//                NSString *videoPath = data[@"data"];
//                if(videoPath.length>0){
//                    [weakSelf handleVideo:videoPath];
//                }
//            }
//        }
//    }];

    [arVC setOpenSDKShareBlock:^(NSString* title, NSString* description, UIImage* thumbImg, NSString* h5Url,NSInteger shareType,NSString *videoOrImageUrl){
        NSLog(@"......%@", title);
        NSLog(@"%@", description);
        NSLog(@"%@", h5Url);
        NSLog(@"%ld", shareType);
        NSLog(@"%@", videoOrImageUrl);
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:h5Url]];
    }];
    arVC.closeEventBlock = ^{
        [weakARVC.navigationController popViewControllerAnimated:YES];
        [weakSelf.navigationController.navigationBar setHidden:NO];
    };

    [self.navigationController pushViewController:arVC animated:YES];
    [self.navigationController.navigationBar setHidden:YES];
#endif
}


- (void)handleVideo:(NSString *)videoPath{
    
    VideoOrImageExhibitionViewController *controller = [[VideoOrImageExhibitionViewController alloc]initControllerWithVideoPath:videoPath];
    [self.navigationController pushViewController:controller  animated:YES];
    
}



- (void)handleImage:(UIImage *)image{
    
    VideoOrImageExhibitionViewController *controller = [[VideoOrImageExhibitionViewController alloc]initControllerWithImage:image];
    [self.navigationController pushViewController:controller  animated:YES];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSString *)dicToString:(NSDictionary *)dic {
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:&error];
    if (error) {
        return nil;
    }
    NSString *jsonString = [[NSString alloc] initWithData:jsonData
                                                 encoding:NSUTF8StringEncoding];
    return jsonString;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
