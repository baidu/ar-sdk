//
//  BARVoiceView.h
//  ARSDK-Voice
//
//  Created by Asa on 2017/6/10.
//  Copyright © 2017年 Asa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Waver.h"

@interface BARVoiceView : UIView

@property (nonatomic, strong) UILabel *contentLabel;
@property (nonatomic, strong) Waver *waver;
@property (nonatomic, strong) UIButton *cancelButton;
@property (nonatomic, strong) UIButton *doneButton;

- (id)initWithFrame:(CGRect)frame;
- (void)startVoiceLevelListening;
- (void)stopVoiceLevelListening;

@end
