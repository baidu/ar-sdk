//
//  BARVoiceView.m
//  ARSDK-Voice
//
//  Created by Asa on 2017/6/10.
//  Copyright © 2017年 Asa. All rights reserved.
//

#import "BARVoiceView.h"
#import <AVFoundation/AVFoundation.h>
#import "BARVoiceClient.h"
#import "BARVoiceHandler.h"
#import "BARVoiceMatchCenter.h"

#define VOICE_LEVEL_INTERVAL 0.1 // 音量监听频率为1秒中10次


@interface BARVoiceView ()<BARVoiceRecogntionDelegate>
{
    CGFloat _normalizedValue;
}
@property (nonatomic, strong) NSTimer *voiceLevelMeterTimer;

@end


@implementation BARVoiceView

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        _normalizedValue = 5;
        [self configureUI];
    }
    return self;
}

- (void)configureUI {
    self.backgroundColor = [UIColor clearColor];
    self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    [self.cancelButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.cancelButton sizeToFit];
    [self.cancelButton addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    self.cancelButton.frame = CGRectMake(10, 0, CGRectGetWidth(self.cancelButton.bounds), CGRectGetHeight(self.cancelButton.bounds));
    [self addSubview:self.cancelButton];
    
    self.doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.doneButton setTitle:@"说完了" forState:UIControlStateNormal];
    [self.doneButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.doneButton sizeToFit];
    [self.doneButton addTarget:self action:@selector(done:) forControlEvents:UIControlEventTouchUpInside];
    self.doneButton.frame = CGRectMake(CGRectGetWidth(self.bounds) - CGRectGetWidth(self.doneButton.bounds) - 10, 0, CGRectGetWidth(self.doneButton.bounds), CGRectGetHeight(self.doneButton.bounds));
    [self addSubview:self.doneButton];
    
    
    self.waver = [[Waver alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.cancelButton.bounds), CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds) - CGRectGetHeight(self.cancelButton.bounds))];
    __weak typeof(self) weakSelf = self;
    weakSelf.waver.waverLevelCallback = ^(Waver * waver) {
        
        //        [weakRecorder updateMeters];
        //
        //        CGFloat tempValue = pow (10, -0.05*_normalizedValue);
        //
        CGFloat tempValue = pow (10, _normalizedValue*0.01);
        
        waver.level = _normalizedValue/10.0f;
        
    };
    [self addSubview:self.waver];
    
    self.contentLabel = [[UILabel alloc] init];
    self.contentLabel.textColor = [UIColor redColor];
    self.contentLabel.frame = CGRectMake(CGRectGetWidth(self.cancelButton.bounds) + 10, 0, CGRectGetWidth(self.bounds) - CGRectGetWidth(self.cancelButton.bounds) - CGRectGetWidth(self.doneButton.bounds) - 20, CGRectGetHeight(self.cancelButton.bounds));
    self.contentLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.contentLabel];
    
}

#pragma mark - private

- (void)cancel:(id)sender {
    [self stopVoiceLevelListening];
    [BARVoiceClient cleanInstance];
}

- (void)done:(id)sender {
    [[BARVoiceClient sharedInstance] speakFinish];
}

- (void)startVoiceLevelMeterTimer
{
    [self freeVoiceLevelMeterTimerTimer];
    
    NSDate *tmpDate = [[NSDate alloc] initWithTimeIntervalSinceNow:VOICE_LEVEL_INTERVAL];
    self.voiceLevelMeterTimer = [[NSTimer alloc] initWithFireDate:tmpDate interval:VOICE_LEVEL_INTERVAL target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_voiceLevelMeterTimer forMode:NSDefaultRunLoopMode];
}

- (void)freeVoiceLevelMeterTimerTimer
{
    if(_voiceLevelMeterTimer)
    {
        if([_voiceLevelMeterTimer isValid])
            [_voiceLevelMeterTimer invalidate];
        self.voiceLevelMeterTimer = nil;
        _normalizedValue = 5;
    }
}

- (void)timerFired:(id)sender
{
    // 获取语音音量级别
    int voiceLevel = [[BARVoiceClient sharedInstance] getCurrentDBLevelMeter];
    _normalizedValue = voiceLevel ?:5;
}

- (void)dealloc {
    [self freeVoiceLevelMeterTimerTimer];
}

- (void)startVoiceLevelListening {
    [self startVoiceLevelMeterTimer];
}

- (void)stopVoiceLevelListening {
    [self freeVoiceLevelMeterTimerTimer];
    [self removeFromSuperview];
}


#pragma mark - BARVoiceClientDelegate

- (void)receivedVoiceRecognitionStatus:(int) aStatus obj:(id)aObj errorStatus:(NSNumber *)errorStatus {
    
    switch (aStatus) {
        case BARVoiceStatusUnKnow:
        {
            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:nil errorId:nil withInfo:nil];
        }
            break;
        case BARVoiceStatusStartWorking:
        {
            [self startVoiceLevelListening];
            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:nil errorId:nil withInfo:nil];
        }
            break;
        case BARVoiceStatusEnd:
        {
            [self stopVoiceLevelListening];
            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:nil errorId:nil withInfo:nil];
        }
            break;
        case BARVoiceStatusFlushData:
        {
            self.contentLabel.text = aObj;
//            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:aObj errorId:nil withInfo:nil];

            [BARVoiceMatchCenter startMatchVoiceRawText:aObj result:^(NSString *resultKey) {
                NSLog(@"=================resultKey %@=======",resultKey);
                if (resultKey) {
                    [[BARVoiceHandler sharedInstance] sendVoiceStatus:BARVoiceStatusFinished voiceResult:resultKey errorId:nil withInfo:nil];
                    [self stopVoiceLevelListening];
                    [[BARVoiceClient sharedInstance] stopVoiceRecognition];
                }
            }];

        }
            break;
        case BARVoiceStatusFinished:
        {
            self.contentLabel.text = aObj;

            [BARVoiceMatchCenter startMatchVoiceRawText:aObj result:^(NSString *resultKey) {
                NSLog(@"=================resultKey %@=======",resultKey);
                if (resultKey) {
                    [[BARVoiceHandler sharedInstance] sendVoiceStatus:BARVoiceStatusFinished voiceResult:resultKey errorId:nil withInfo:nil];
                }else {
                    [[BARVoiceHandler sharedInstance] sendVoiceStatus:BARVoiceStatusFinishedNoCmd voiceResult:nil errorId:nil withInfo:nil];
                }
            }];
            
            [self stopVoiceLevelListening];
            UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_None;//(扬声器)
                AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRouteOverride), &audioRouteOverride);

        }
            break;
        case BARVoiceStatusCancel:
        {
            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:nil errorId:nil withInfo:nil];
            [self stopVoiceLevelListening];
        }
            break;
        case BARVoiceStatusError:
        {
            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:nil errorId:errorStatus withInfo:nil];
            [self stopVoiceLevelListening];
        }
            break;
        default:
        {
            [[BARVoiceHandler sharedInstance] sendVoiceStatus:aStatus voiceResult:nil errorId:nil withInfo:@{}];
            [self stopVoiceLevelListening];
        }
            break;
    }
}

@end
