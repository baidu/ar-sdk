//
//  BARVoiceViewController.h
//  BDARClientSample
//
//  Created by Asa on 2017/6/22.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BARVoiceViewController : UIViewController
@property(nonatomic,strong)NSDictionary *arDic;
@end
