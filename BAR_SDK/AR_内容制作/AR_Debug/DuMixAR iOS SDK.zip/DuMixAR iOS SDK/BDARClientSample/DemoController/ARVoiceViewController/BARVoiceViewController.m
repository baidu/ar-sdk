//
//  BARVoiceViewController.m
//  BDARClientSample
//
//  Created by Asa on 2017/6/22.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import "BARVoiceViewController.h"
#import "BARVoiceClient.h"
#import "BARVoiceView.h"
#import "BARVoiceHandler.h"
#import "BaiduARSDK.h"
#import "NSDictionary+ToString.h"

#define KBaiDuYuYin_ApiKey @"GGclg1AK0gkNOROcLWcQVag4"
#define KBaiduYuYin_SecretKey @"yehb1IgG0xDdxUUCaV6lfhG0F67rQi4W"

@interface BARVoiceViewController ()

@end

@implementation BARVoiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIButton *startButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [startButton setTitle:@"开始语音AR" forState:UIControlStateNormal];
    [startButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [startButton sizeToFit];
    startButton.frame = CGRectMake(CGRectGetWidth(self.view.bounds)/2 - CGRectGetWidth(startButton.bounds)/2, CGRectGetHeight(self.view.bounds)/2 - CGRectGetHeight(startButton.bounds)/2, CGRectGetWidth(startButton.bounds), CGRectGetHeight(startButton.bounds));
    [startButton addTarget:self action:@selector(startVoiceAR) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:startButton];
}

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)startVoiceAR {
    __weak typeof([BARVoiceClient sharedInstance]) weakClient = [BARVoiceClient sharedInstance];
    [[BARVoiceClient sharedInstance] setListenCurrentDBLevelMeter:YES];
    [BARVoiceClient sharedInstance].configureListenViewBlcok = ^{
        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        BARVoiceView *voiceView = [keyWindow viewWithTag:2017];
        if (!voiceView) {
            voiceView = [[BARVoiceView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(keyWindow.bounds) - 200, CGRectGetWidth(keyWindow.bounds), 50)];
            voiceView.tag = 2017;
            [keyWindow addSubview:voiceView];
        }
        weakClient.delegate = (id<BARVoiceRecogntionDelegate>)voiceView;
    };
    [[BARVoiceClient sharedInstance] setApiKey:KBaiDuYuYin_ApiKey withSecretKey:KBaiduYuYin_SecretKey];
    [[BARVoiceHandler sharedInstance] addLuaObserver];
    
    
    
//    NSString *arKey = @"10000603";
//    NSDictionary *dic1 = @{@"ar_key":arKey,@"ar_type":@(0)};
    NSString *arKey = self.arDic[@"ar_key"];
    NSString *arType = self.arDic[@"ar_type"];
    NSDictionary *dic1 = @{@"ar_key":arKey,@"ar_type":arType};

    NSString *value = [dic1 toString];
    BARViewController *tVC = [BaiduARSDK viewController:value arInfo:nil];
    
    __weak BARViewController* weakTVC = tVC;
    tVC.closeEventBlock = ^{
        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        BARVoiceView *voiceView = [keyWindow viewWithTag:2017];
        [voiceView removeFromSuperview];
        [BARVoiceClient cleanInstance];
        [[BARVoiceHandler sharedInstance] removeLuaObserver];
        [weakTVC dismissViewControllerAnimated:true completion:nil];
    };
    [tVC setScreenImageBlock:^(UIImage *image){
        NSLog(@"ScreenImageBlock: %f",image.size.width);
    }];
    [tVC setScreenVideoBlock:^(NSString *videoPath){
        NSLog(@"ScreenVideoBlock: %@",videoPath);
    }];
    
    self.navigationController.navigationBar.hidden = true;
    [self presentViewController:tVC animated:true completion:nil];

}

@end
