//
//  AppDelegate.m
//  BDARClientSample
//
//  Created by Tony_Q on 2017/6/19.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import "AppDelegate.h"
#if TARGET_IPHONE_SIMULATOR
#else
#import "BaiduARSDK.h"
#endif

//#error 请在官网创建应用，并在此填写相关参数

#define APP_ID       @""                            // 您创建应用的 AppID
#define API_KEY      @""                            // 您创建应用的 API_KEY
#define SECRET_KEY   @""                            // 您创建应用的 SECRET_KEY

@interface AppDelegate ()
@property (assign, nonatomic) UIBackgroundTaskIdentifier backgroundTaskId;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
#if TARGET_IPHONE_SIMULATOR
#else
    if ([BaiduARSDK isSupportAR]) {
        [BaiduARSDK setBundlePath:@"BaiduAR.bundle"];
        [BaiduARSDK openTimeStatistics:YES];
        [BaiduARSDK setAppID:APP_ID APIKey:API_KEY andSecretKey:SECRET_KEY];
    } else {
        NSLog(@"该设备不支持");
    }
#endif
    // Override point for customization after application launch.
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    __weak __typeof__ (self) wself = self;
    self.backgroundTaskId = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        __strong __typeof (wself) sself = wself;
        if(sself){
            [[UIApplication sharedApplication]endBackgroundTask:sself.backgroundTaskId];
            sself.backgroundTaskId = UIBackgroundTaskInvalid;
        }
        
    }];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    return UIInterfaceOrientationMaskPortrait;
}


@end
