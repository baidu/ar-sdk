is8_5 = (ae.ARApplicationController ~= nil)

-- if is8_5 then
--     io.write(" ==============  8.5 == 8.5 == 8.5  ==================")
--     app_controller = ae.ARApplicationController:shared_instance()
--     application = app_controller:add_application_with_type(2, "slam_bear_application")
-- else
    io.write(" ==============  8.4 == 8.4 == 8.4  ==================")
    application = ae.ARApplication:shared_application()
-- end




-- local application = ae.ARApplication:shared_application()
--注册app加载完成之后的回调
  lua_handler = application:get_lua_handler()
local appLoadedHandlerId = lua_handler:register_handle("onApplicationDidLoad")
  application:set_on_loading_finish_handler(appLoadedHandlerId)



-- application:play_bg_music("/res/media/bgm.mp3", -1, 0)


--从JSON中加
-- if is8_5 then
-- io.write(" ==============  8.5 == 8.5 == 8.5  ==================")
  application:add_scene_from_json("res/simple_scene.json","demo_scene")
-- else
-- io.write(" ==============  8.4 == 8.4 == 8.4  ==================")
--   application:add_scene_from_json("res/simple_scene.json","demo_scene","common_config8_4.json")
-- end




--激活场景
  application:active_scene_by_name("demo_scene")
  

--配置NODE
  current_scene = application:get_current_scene()

 -- 通过节点名从场景中获取对应node

    -- 灰色蒙板
  all_screen = current_scene:get_node_by_name("all_Screen") 

  -- 初始显示欢迎页
  
  if is8_5 then
    io.write(" ==============  8.5 == 8.5 == 8.5  ==================")
    welcome5_show = current_scene:get_node_by_name("welcome5_Show")
    welcome5_show:set_visible(true)
    welcome_show = welcome5_show

  else
    io.write(" ==============  8.4 == 8.4 == 8.4  ==================")
    welcome4_show = current_scene:get_node_by_name("welcome4_Show")
    welcome4_show:set_visible(true)
    welcome_show = welcome4_show

  end

  -- 初始go按钮
  go_show = current_scene:get_node_by_name("go_Show")

  -- walk 动画的模型
  walk_node = current_scene:get_node_by_name("walk_Node")  
  walk_node1 = current_scene:get_node_by_name("walk_Node_houzi")  
  walk_node1:set_touchable(true)

  -- 点击walk_node 后 播放 动画的模型
  roar_node = current_scene:get_node_by_name("roar_Node")

  -- 点击Book显示文字/切换closeBook
  click_book = current_scene:get_node_by_name("click_Close_Book")
  -- 点击closeBook隐藏文字/切换Book
  click_close_book = current_scene:get_node_by_name("click_Open_Book")
  -- 点击复位
  click_reset = current_scene:get_node_by_name("click_Reset")
  -- 点击跳转百度百科
  click_open_url = current_scene:get_node_by_name("click_OpenUrl")
  -- 当点击Book按钮,显示动物名称卡片
  show_text_card = current_scene:get_node_by_name("show_TextCard")

  -- BLN 显示
  bln_light1 = current_scene:get_node_by_name("BLN_Light1")
  bln_light2 = current_scene:get_node_by_name("BLN_Light2")



function onApplicationDidLoad()


  -- go点击
  local onClickGoHandler = lua_handler:register_handle("click_Go")
  go_show:set_event_handler(0,onClickGoHandler)

  click_Go()

  -- Book点击
  local onClickBookHandler = lua_handler:register_handle("click_Book")
  click_book:set_event_handler(0,onClickBookHandler)

  -- closeBook点击
  local onClickCloseBookHandler = lua_handler:register_handle("click_Close_Book")
  click_close_book:set_event_handler(0,onClickCloseBookHandler)

  -- reset点击
  local onClickResetHandler = lua_handler:register_handle("click_Reset")
  click_reset:set_event_handler(0,onClickResetHandler)

  -- open_url点击
  local onClickOpenUrlHandler = lua_handler:register_handle("click_Open_Url")
  click_open_url:set_event_handler(0,onClickOpenUrlHandler)

  -- 模型点击
  walk_node:set_touchable(true)
  local onClickSceneHandler = lua_handler:register_handle("click_Roar_Anim")
  walk_node:set_event_handler(0,onClickSceneHandler)


end




function click_Go()
  -- 点击go按钮
  -- 开启IMU
  application:open_imu_service(1)


  all_screen:set_visible(false)
  
  welcome_show:set_visible(false)
  go_show:set_visible(false)
  -- 调起AR后,动物动作
  walk_Anim()

  -- 当用户点击GO,右边按钮才可点击
  click_book:set_touchable(true)
  click_book:set_visible(true)
  click_close_book:set_touchable(true)
  click_reset:set_touchable(true)
  click_reset:set_visible(true)
  click_open_url:set_touchable(true)
  click_open_url:set_visible(true)
  bln_light1:set_visible(true)
  bln_light2:set_visible(true)
  BLN_scale_anim("BLN_Light1")
  
  click_Book()

end


function BLN_scale_anim(nodeName)
  -- 呼吸灯动态显示

   local node = current_scene:get_node_by_name(nodeName)
   local scfg = ae.ActionPriorityConfig:new()
   local scale_id = ae.ScaleMotionParam:new()
   scale_id._src_xyz = "1,1,1"
   scale_id._dst_xyz = "0.5,0.5,0.5"
   scale_id._repeat_mode = 1
   scale_id._duration = 1000
   scale_id._repeat_max_count = 1000
   scale_id._delay = 0

   nodeName = node:play_rigid_anim(scale_id,scfg)

end



function click_Book()
  -- 点击 Book 按钮

  -- 当用户点击Book按钮,音频播放完还未点击关闭按钮,默认3S 后自动关闭
  local defaultNoClickPerform = lua_handler:register_handle("click_Close_Book")

  click_book:set_visible(false)
  click_close_book:set_visible(true)
  show_text_card:set_visible(true)
  audio_id = click_book:play_audio("res/media/monkey_introduce.mp3",1,0)

  -- 默认不点击执行
  local default_no_click_perform = click_book:set_action_completion_handler(audio_id,defaultNoClickPerform)

end


function click_Close_Book()
  -- 点击 closeBook 按钮
  click_close_book:set_visible(false)
  click_book:set_visible(true)
  show_text_card:set_visible(false)
  click_book:stop_action(audio_id)

end


function click_Reset()
  -- 点击 reset 按钮
  application:relocate_current_scene()

end


function click_Open_Url()
  -- 点击open_url 按钮
  application:open_url("https://voice.baidu.com/Graph/arcase",0)

end


function walk_Anim()
  -- 动物持续动作

  walk_node:set_visible(true)
  roar_node:set_visible(false)
  walk_node:play_pod_animation_all(0.5,0)

end



function click_Roar_Anim()
  -- 动物点击动作

  io.write("wo bei dianji l ")
  local handler_id = lua_handler:register_handle("walk_Anim")

  walk_node:set_visible(false)
  roar_node:set_visible(true)
  roar_node:play_audio("res/media/monkey_shout.mp3",1,700)
  local anim_id = roar_node:play_pod_animation_all(0.5,1)

  -- 点击模型动画结束后,调动物持续动作
  roar_node:set_action_completion_handler(anim_id,handler_id)

  bln_light1:set_visible(false)
  bln_light2:set_visible(false)

end












