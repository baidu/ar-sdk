//
//  ViewController.m
//  BDARClientSample
//
//  Created by Tony_Q on 2017/6/19.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import "ViewController.h"
#import "ARDemoDetailViewController.h"
#if TARGET_IPHONE_SIMULATOR
#else
#import "BaiduARSDK.h"
#import "BARViewController.h"
#endif
#define IS_IPHONE_X ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic,strong)NSArray *arObjArray;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.navigationController.navigationBar setHidden:NO];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"DuMix AR Demo";
    // 参考"SDK集成步骤"中的【第7步】将您获取的 AR Key 和 AR Type 填入到下方，不用的功能请注释
    self.arObjArray = @[
                        @{@"demotype":@"ar",
                          @"ar_key":@"",
                          @"ar_type":@"5",
                          @"title":@"单目SLAM （Monocular SLAM）",
                          @"describe":@"即时定位与跟踪的AR效果，将AR内容自然地呈现在现实空间中，可广泛应用于3D人物角色、3D商品模型展示等场景，例如AR车展、AR宠物小精灵等。"
                          },
                        @{@"demotype":@"ar",
                          @"ar_key":@"",
                          @"ar_type":@"6",
                          @"title":@"本地识别 （On-Device IR）",
                          @"describe":@"在手机端进行图像识别检索，用于实现基于2D图片的AR内容识别触发，可集成在扫一扫等固定AR入口，方便培养用户对AR的认知，从云端下发更新识图特征库文件，建议控制在1000个以内。"
                          },
                        @{@"demotype":@"ar",
                          @"ar_key":@"",
                          @"ar_type":@"7",
                          @"title":@"云端识别 （Cloud IR）",
                          @"describe":@"云端图像识别检索，用于实现基于2D图片的AR内容识别触发，可集成在扫一扫等固定AR入口，方便培养用户对AR的认知，从本地上传相机获取的特征文件至云端返回检索结果，建议在wifi、4G、3G等网络环境下使用。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入你上传的2D Tracking的包对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"图片跟踪 （2D Tracking）",
                          @"describe":@"对平面图像进行即时识别和跟踪，可基于商品外包装、宣传海报、印刷品、服饰图案等局部图片触发AR内容，广泛用于AR品牌营销、AR图书、AR户外广告、AR展览展示、AR特效服饰等场景。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入你上传的imu的包对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"空间定位 （IMU）",
                          @"describe":@"基于手机IMU，实时获取手机在空间中的相对位置和姿态，将AR内容定位呈现在手机当前所处的三维空间中，可使用的内容素材包括图片、透明视频、3D模型动画等，广泛应用于线上banner图或文字链等直接调启AR营销推广内容的场景。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入您上传的语音的包对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"语音识别 （Speech Recognition）",
                          @"describe":@"结合百度语音识别技术，实现自然语言与AR内容之间的交互能力。在调启AR后，通过预置的语音指令输入引导，触发语音识别能力，实现通过用户语音输入触发对应的AR交互内容。例如引导用户喊出“请财神”展现财神出场动效，引导用户询问“怎么服用”介绍药品的服用说明。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入您上传的TTS的包对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"语音合成 （TTS）",
                          @"describe":@"结合百度语音合成技术，能将AR内容中配置的文字转换成流畅自然的语音输出。可广泛应用于场景中需要语音介绍、语音播报、语音引导、语音反馈的环节。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入您对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"滤镜",
                          @"describe":@"支持对相机背景、模型叠加滤镜效果。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入您对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"LOGO识别",
                          @"describe":@"结合logo识别，实现logo识别能力与AR内容之间的交互能力。在调起AR后，通过扫描特定的logo，触发对应的AR交互内容。例如：引导用户扫描“百度logo”，可跳转到百度的网站或者展示出模型。 "
                          },
                        @{@"demotype":@"ar",
#warning 请输入您对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"手势识别",
                          @"describe":@"结合手势识别，实现手势识别能力与AR内容之间的交互能力。在调起AR后，通过扫描特定的手势，触发对应的AR交互内容。例如：引导用户扫描“手掌”，可出现请财神模型。"
                          },
                        @{@"demotype":@"ar",
#warning 请输入您对应的arkey
                          @"ar_key":@"",
                          @"ar_type":@"0",
                          @"title":@"支持配置在线视频格式的AR增强内容",
                          @"describe":@"支持配置在线视频格式的AR增强内容"
                          },
                        ];
    [self initARSDK];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)initARSDK {
    //sdk 初始化
}

- (void)onClicked:(NSInteger)row{
    NSDictionary *dic = self.arObjArray[row];
    NSString *demoType = dic[@"demotype"];
    if ([demoType isEqualToString:@"ar"]) {
        [BaiduARSDK setLocalARResourceName:nil];
        ARDemoDetailViewController *vc = [[ARDemoDetailViewController alloc]init];
        vc.arDic = dic;
        vc.navigationItem.title = dic[@"title"];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (0 == section) {
        return 1;
    }else {
        return self.arObjArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"CellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    if (0 == indexPath.section) {
        cell.textLabel.text = @"本地调试";
    }else {
        NSDictionary *doic = self.arObjArray[indexPath.row];
        cell.textLabel.text = doic[@"title"];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (0 == indexPath.section) {
        __weak typeof(self) weakSelf = self;
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"输入ARType" message:nil preferredStyle:UIAlertControllerStyleAlert];
        __weak typeof(alert) weakAlert = alert;
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alert addAction:cancelAction];
        
        UIAlertAction *nextAction = [UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            UITextField *textField = weakAlert.textFields[0];
            NSString *arType = textField.text;
            [weakSelf showLocalAR:arType];
        }];
        [alert addAction:nextAction];
        

        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"ARType";
        }];
        
        [self presentViewController:alert animated:YES completion:NULL];

    }else {
        [self onClicked:indexPath.row];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 58.0f;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showLocalAR :(NSString *)artype{
#if TARGET_IPHONE_SIMULATOR
#else
    if ([artype isEqualToString:@""]) {
        artype = @"0";
    }
    
   BOOL result =  [BaiduARSDK setLocalARResourceName:@"local"];
    if (!result) {
        return;
    }
    NSString* arValue = [NSString stringWithFormat:@"{\"arKey\":\"%@\",\"arType\":\"%@\",\"arLoc\":\"\",\"ar_key\":\"%@\",\"ar_type\":\"%@\",\"ar_launch_mode\":\"1\"}",@"0",artype,@"0",artype];
    
    BARViewController *arVC = [BaiduARSDK viewController:arValue  arInfo:nil];
    __weak BARViewController *weakARVC = arVC;
    
    __weak typeof (self) weakSelf = self;
    [arVC setClickEventBlock:^(NSString* url) {
        
        if (weakSelf) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.navigationController popToRootViewControllerAnimated:NO];
                [weakSelf.navigationController.navigationBar setHidden:NO];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
            });
        }
    }];
    
    
    //退化方案，当您的设备不支持当前case的时候会跳转到帮助页面
    [arVC setDumixARRefuseEventBlock:^(NSString *url) {
        if (weakSelf) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.navigationController popToRootViewControllerAnimated:NO];
                [weakSelf.navigationController.navigationBar setHidden:NO];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
            });
        }
    }];
    
    [arVC setCloseEventBlock:^(void){
        if (weakSelf) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakARVC.navigationController popViewControllerAnimated:YES];
                [weakSelf.navigationController.navigationBar setHidden:NO];
            });
        }
    }];
    
    
    [arVC setOpenSDKShareBlock:^(NSString* title, NSString* description, UIImage* thumbImg, NSString* h5Url,NSInteger shareType,NSString *videoOrImageUrl){
        NSLog(@"......%@", title);
        NSLog(@"%@", description);
        NSLog(@"%@", h5Url);
        NSLog(@"%ld", shareType);
        NSLog(@"%@", videoOrImageUrl);
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:h5Url]];
    }];
    arVC.closeEventBlock = ^{
        [weakARVC.navigationController popViewControllerAnimated:YES];
        [weakSelf.navigationController.navigationBar setHidden:NO];
    };
    [self.navigationController pushViewController:arVC animated:YES];
    [self.navigationController.navigationBar setHidden:YES];
#endif
}
@end
