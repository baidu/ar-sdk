-- slam.lua --
function SLAM()
	local Slam = {}
	function Slam.slam_reset(self, x, y, depth)
        io.write(" zbb : x : ")
    	local mapData = ae.MapData:new() 
        mapData:put_int("id", MSG_TYPE_SLAM_RESET) 
        mapData:put_float("x",x)
        mapData:put_float("y",y)
        mapData:put_int("type",2)
        mapData:put_float("distance",depth)
        AR.current_application.lua_handler:send_message_tosdk(mapData)
	end
	return Slam
end
-- slam.lua end --

