app_controller = ae.ARApplicationController:shared_instance()
app_controller:require("./scripts/include.lua")
app = AR:create_application(AppType.ImageTrack, "bear")
app:load_scene_from_json("res/simple_scene.json", "initial_scene")

scene = app:get_current_scene()
local  filterStartID = 500000
local  filterlastID = 500011
local  clickNum = 1
local  current = 0 
local  last = 1

app.on_loading_finish = function ( )
    app.device:open_imu(1)
    
    scene.bear:pod_anim():anim_repeat(true):start()
    Filter:start()

    scene.next.on_click=function (  )
        clickNum=1
        scene.filtermodel:replace_texture("/res/texture/on.png","uDiffuseTexture")
        current = current+1
        if(current>=11)then
            current=0
        end
            scene:get_node_by_name(1):set_visible(false)
            scene:get_node_by_name(2):set_visible(false)
            scene:get_node_by_name(3):set_visible(false)
            scene:get_node_by_name(4):set_visible(false)
            scene:get_node_by_name(5):set_visible(false)
            scene:get_node_by_name(6):set_visible(false)
            scene:get_node_by_name(7):set_visible(false)
            scene:get_node_by_name(8):set_visible(false)
            scene:get_node_by_name(9):set_visible(false)
            scene:get_node_by_name(10):set_visible(false)

        Filter:update(filterStartID+current)
        scene:get_node_by_name(current):set_visible(true)


    end
    scene.pre.on_click = function ( )
        clickNum=1
        scene.filtermodel:replace_texture("/res/texture/on.png","uDiffuseTexture")
        current = current-1
        if(current< 0)then
            current = 10
        end
            scene:get_node_by_name(1):set_visible(false)
            scene:get_node_by_name(2):set_visible(false)
            scene:get_node_by_name(3):set_visible(false)
            scene:get_node_by_name(4):set_visible(false)
            scene:get_node_by_name(5):set_visible(false)
            scene:get_node_by_name(6):set_visible(false)
            scene:get_node_by_name(7):set_visible(false)
            scene:get_node_by_name(8):set_visible(false)
            scene:get_node_by_name(9):set_visible(false)
            scene:get_node_by_name(10):set_visible(false)

        Filter:update(filterStartID+current)
        scene:get_node_by_name(current):set_visible(true)
    end

    scene.filtermodel.on_click=function ( )
        if(clickNum==1)then
        Filter:disable_target(filterStartID+current,"reality_target",1)
        Filter:disable_target(filterStartID+current,"mix_target",0)
        Filter:update(filterStartID+current)
        scene.filtermodel:replace_texture("/res/texture/off.png","uDiffuseTexture")
        clickNum=clickNum+1
        elseif(clickNum==2)then
        Filter:disable_target(filterStartID+current,"mix_target",1)
        Filter:disable_target(filterStartID+current,"reality_target",0)
        Filter:update(filterStartID+current)
        scene.filtermodel:replace_texture("/res/texture/on.png","uDiffuseTexture")
        clickNum=clickNum-1     
        end
    end
end
 