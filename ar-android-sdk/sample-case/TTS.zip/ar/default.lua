app_controller = ae.ARApplicationController:shared_instance()
app_controller:require('./scripts/include.lua')
app = AR:create_application(AppType.ImageTrack, "bear")
app:load_scene_from_json("res/simple_scene.json","demo_scene")

scene = app:get_current_scene()
local version = app:get_engine_version()

print(type(version) ..' === === = == = == '.. version)
ARLOG(' ======================================================================')

	app.on_loading_finish = function()

	    ae.LuaUtils:call_function_after_delay(500, "start")
	
	    scene.go_Show.on_click = function()
		    click_Go()
	    end
end

function start()
  scene.go_Show:set_visible(true)
end


scene.pause.on_click = function ()
ARLOG(" +++++++++++++ TTS暂停~ ++++++++++++++++ ")
    Tts:pause()
end

scene.stop.on_click = function ()
ARLOG(" +++++++++++++ TTSStop~ ++++++++++++++++ ")
    Tts:stop()    
end

scene.resume.on_click = function ()
ARLOG(" +++++++++++++ TTSResume~ ++++++++++++++++ ")
Tts:resume()
end


function click_Go()
  -- 点击go按钮

  scene.go_Show:set_visible(false)
  Tts:speak('单嵴龙是种斑龙超科食肉恐龙，生存于侏罗纪中期的中国，约1亿7000万年前。单脊龙的属名意为有单冠饰的蜥蜴，'
     ..'意指它们头颅骨上的单一冠饰。单脊龙的身长可达5米，高度为1.7米，重量可达450公斤。单脊龙的发现地区，被发现出有水的迹象，所以单脊龙可能生存在湖岸或海岸地区，而且被认为以鱼类和小型恐龙为主食，因为它们细的嘴巴、整齐的牙齿、灵活的颈部，很适合捕食鱼类，较灵活和敏捷的身体结构，'
     ..'使得它们也很擅长猎杀奔跑速度快的小型恐龙。','2','5','0.5')

end

-- tts 控制器
tts_index = 0

-- TTS 回调响应 --
Tts.callBack = function(data)
	ttsCallback(data)
end

-- TTS callback
function ttsCallback(mapData)

	local status = mapData['status']
	io.write(' lua tts status '..status)
	if(status ~= nil) then
		if(status == TTS_STATUS_READYFORTTS) then
			ARLOG('TTS开始说话')
		end
		if(status == TTS_STATUS_ENDOFTTS) then
			ARLOG('TTS说话结束')
		end
		if(status == TTS_STATUS_ERROR) then
			ARLOG('TTS说话错误')
		end
	end
end	






