precision mediump float;
varying vec4 outcolor;
void main()
{
    gl_FragColor = vec4(1.0, 1.0, 1.0, 1.0);
   // gl_FragColor = outcolor;
}


