local application = ae.ARApplication:shared_application()
--注册app加载完成之后的回调
lua_handler = application:get_lua_handler()
local appLoadedHandlerId = lua_handler:register_handle("onApplicationDidLoad")
-- local trackingLostHandlerId = lua_handler:register_handle("onTrackingLoss")
-- local trackingFoundHandlerId = lua_handler:register_handle("onTrackingFound")

application:set_on_loading_finish_handler(appLoadedHandlerId)
-- application:set_on_tracking_lost_handler(trackingLostHandlerId)
-- application:set_on_tracking_found_handler(trackingFoundHandlerId)

local startButtonClickHandler = lua_handler:register_handle("onSimpleButtonClick")

local onHideAnimCompletedHandler = lua_handler:register_handle("onHideAnimCompleted");

local resumeButtonClickHandler = lua_handler:register_handle("onResumeButtonClick");

application:play_bg_music("/res/media/bgm.mp3", -1, 0)
-- application:pause_bg_music()

--从JSON中加
application:add_scene_from_json("res/simple_scene.json","demo_scene")
--从JSON中加载场景
-- application:add_scene_from_json("res/simple_scene2.json","demo_scene2")
--激活场景
application:active_scene_by_name("demo_scene")
application:set_gl_cull_face(true)

--配置NODE
local current_scene = application:get_current_scene()

function onApplicationDidLoad()

  application:open_imu_service(1)


  local resume_button = current_scene:get_node_by_name("ResumeButton")
  resume_button:set_event_handler(0, resumeButtonClickHandler)

  local  start_button = current_scene:get_node_by_name("StartButton")
  start_button:set_event_handler(0, startButtonClickHandler)


	setBirdEyeView()
end

function onTrackingLoss()
	setBirdEyeView()
end

-- function onTrackingFound()
--   application:resume_bg_music()
-- end

function setBirdEyeView()
    application:set_camera_look_at("0.0, 90.0, 800.0","0, 0, 0", "0, 2.0, 1.0")
end

function onResumeButtonClick()
	--application:reset()
	application:relocate_current_scene()
end


       
--点击场景1按钮，加载财神
function onSimpleButtonClick()
application:open_imu_service(1)

local current_scene1 = application:get_current_scene()
local root_node = current_scene1:get_root_node()
io.write("play music..")
root_node:play_audio("/res/media/sound.wav", 1, 0)


if root_node then
end

hideNode("ContentPlane",application:get_current_scene())
hideNode("StartButton",application:get_current_scene())


-- local other_node = current_scene1:get_node_by_name("s1_simplePod")
-- other_node:play_pod_animation_all(0.5,false)

-- local  other_node1 = current_scene1:get_node_by_name("s2_simplePod")
-- other_node1:play_pod_animation_all(0.5,true)

root_node:play_pod_animation_all(1, false,1,55)
root_node:play_pod_animation_all(1,true,55,256)

showNode("s1_simplePod",application:get_current_scene())
-- showNode("s2_simplePod",application:get_current_scene())



-- ae.LuaUtils:call_function_after_delay(600, "onS2Show")

end




-- function onS2Show()
-- --激活场景
-- application:switch_to_scene_with_name("demo_scene2")

-- local root_node = current_scene:get_root_node()
--   --io.write("play music..")
--     if root_node then
--     end
  
--   root_node:play_pod_animation_all(1, true)


-- local current_scene2 = application:get_current_scene()

-- local resume_button = current_scene2:get_node_by_name("ResumeButton")
-- resume_button:set_event_handler(0, resumeButtonClickHandler)

-- local share_button = current_scene2:get_node_by_name("shareButton")
-- share_button:set_event_handler(0, shareButtonClickHandler)

-- _simple_button2 = current_scene2:get_node_by_name("simpleButton")
-- _simple_button2:set_event_handler(0, simpleButtonClickHandler2)

--   showNode("s2_simplePod1",application:get_current_scene())
--   showNode("s2_simplePod",application:get_current_scene())
--   showNode("s2_simplePod2",application:get_current_scene())
--   showNode("simpleButton",application:get_current_scene())
-- end

-- function onS1Show()
-- --从JSON中加载场景
-- application:switch_to_scene_with_name("demo_scene")

-- showNode("StartButton",application:get_current_scene())
-- -- showNode("ContentPlane",application:get_current_scene())
-- -- showNode("ShadowPlane",application:get_current_scene())
-- showNode("s1_simplePod",application:get_current_scene())
-- showNode("s1_simplePod2",application:get_current_scene())
-- showNode("simpleButton",application:get_current_scene())
-- end

willHideNodes = {}

function hideNode(nodeName,scene)
   local node = scene:get_node_by_name(nodeName)
   local scfg = ae.ActionPriorityConfig:new()
   scfg.forward_logic = 1
   local s = ae.ScaleMotionParam:new()
   s._src_xyz = "1,1,1"
   s._dst_xyz = "0.1,0.1,0.1"
   s._delay = 0
   s._duration = 500
   --s._repeat_mode = 1
   local animId = node:play_rigid_anim(s,scfg)
   willHideNodes[tostring(animId)] = nodeName
   node:set_action_completion_handler(animId, onHideAnimCompletedHandler)
end

function onHideAnimCompleted(status, animId)
    local nodeName = willHideNodes[tostring(animId)]
    if nodeName then
    local node = application:get_current_scene():get_node_by_name(nodeName)
    node:set_visible(false)
    node:reset_rts()
    willHideNodes[tostring(animId)] = nil
    end
end

function showNode(nodeName,scene)
    local node = scene:get_node_by_name(nodeName)

    local scfg = ae.ActionPriorityConfig:new()
    scfg.forward_logic = 1
    local s = ae.ScaleMotionParam:new()
    s._src_xyz = "0.1, 0.1, 0.1"
    s._dst_xyz = "1,1,1"
    s._delay = 0
    s._duration = 500
    --s._repeat_mode = 1
    node:play_rigid_anim(s,scfg)
    node:set_visible(true)
end

function showNode2(nodeName,scene)
local node = scene:get_node_by_name(nodeName)

--node:get_sub_node_by_name("shu_shugan").set_scale(10.0, 10.0, 10.0)
local scfg = ae.ActionPriorityConfig:new()
scfg.forward_logic = 1
local s = ae.TranslateMotionParam:new()
s._src_xyz = "-100, -100, 0"
s._dst_xyz = "100,100,0"
s._delay = 500
s._duration = 500
--s._repeat_mode = 1
node:play_rigid_anim(s,scfg)
node:set_visible(true)
end
